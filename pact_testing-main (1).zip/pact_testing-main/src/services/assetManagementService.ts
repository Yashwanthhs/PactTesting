import axios from "axios";

export class AssetManagementService {
    url: any;
    constructor(url: string) {
        if (url === undefined || url === "") {
            url = process.env.APP_BASE_URL ? process.env.APP_BASE_URL : "";
        }
        if (url.endsWith("/")) {
            url = url.substr(0, url.length - 1)
        }
        this.url = url
    }
    async getAllChargers() {
        return axios.get(`${this.url}/chargers`)
            .then(r => r.data);
    }

    async getCharger(id: string) {
        return axios.get(`${this.url}/charger/${id}`)
            .then(r => r.data);
    }

    async addCharger(chargerInfo: any) {
        return axios.post(`${this.url}/charger`, chargerInfo)
            .then(r => r.data);
    }

    async updateCharger(id: string, chargerInfo: any) {
        return axios.put(`${this.url}/charger/${id}`, chargerInfo)
            .then(r => r.data);
    }

    async deleteCharger(id: string) {
        return axios.delete(`${this.url}/charger/${id}`)
            .then(r => r.data);
    }
}