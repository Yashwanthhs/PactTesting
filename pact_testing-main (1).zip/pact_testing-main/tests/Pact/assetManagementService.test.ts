import path = require("path");
import { Pact, Matchers } from "@pact-foundation/pact";
import { AssetManagementService } from "../../src/services/assetManagementService";
import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
chai.use(chaiAsPromised);
const expect = chai.expect;

const { eachLike, like, term } = Matchers
const usePort = 8081;


describe("get all chargers API", () => {
    const provider = new Pact({
        port: usePort,
        log: path.resolve(process.cwd(), "logs", "mockserver-integration.log"),
        dir: path.resolve(process.cwd(), "pacts"),
        spec: 2,
        consumer: "BackendAPP",
        provider: "AssetManagementService",
    })

    const getChargerByIDExample = {
        chargerID: "PactTestCharger2",
        commonName: "PactTestCharger2",
        authorizationState: true,
        location: {
            lon_X: 95.2735,
            lat_Y: 36.7389
        },
        chargerVersion: null,
        chargerType: "SiemensCharger",
        chargingMode: "STD",
        modelID: null,
        power: 11.5,
        connected: false,
        efficiency: 100,
        dataIngestRate: 60,
        isAuthRequired: false,
        connectors: [
            {
                connectorID: 1,
                power: 11.5,
                type: "ACPlugIn",
                pluginType: null,
                parkingSpace: 3,
                parkingSpaceId: 12345
            }
        ],
        identifier: "c603389f02b64fb8a8a2fadef871c22f",
        chargerStatus: "Faulted",
        connectionState: "false"
    }

    const getChargerByIDBody = {
        chargerID: like("PactTestCharger2"),
        commonName: like("PactTestCharger2"),
        authorizationState: like(true),
        location: like({
            lat_Y: like(36.7389),
            lon_X: like(95.2735)
        }),
        chargerVersion: null,
        chargerType: like("SiemensCharger"),
        chargingMode: term({
            matcher: "STD|SEQ",
            generate: "STD",
        }),
        modelID: null,
        power: like(11.5),
        connected: like(false),
        efficiency: like(100),
        dataIngestRate: like(60),
        isAuthRequired: like(false),
        connectors: eachLike({
            connectorID: 1,
            power: 11.5,
            type: "ACPlugIn",
            pluginType: null,
            parkingSpace: 3,
            parkingSpaceId: 12345
        }),
        identifier: like("c603389f02b64fb8a8a2fadef871c22f"),
        chargerStatus: like("Faulted"),
        connectionState: like("false")
    };

    const getChargerListExpectation = eachLike(getChargerByIDBody, {
        min: 1,
    });

    const addChargerExample = {
        chargerID: "PactTestCharger3",
        commonName: "PactTestCharger3",
        authorizationState: true,
        location: {
            lon_X: 95.2735,
            lat_Y: 36.7389
        },
        chargerVersion: null,
        chargerType: "SiemensCharger",
        chargingMode: "STD",
        modelID: null,
        power: 11.5,
        connected: false,
        efficiency: 100,
        dataIngestRate: 60,
        isAuthRequired: false,
        connectors: [
            {
                connectorID: 1,
                power: 11.5,
                type: "ACPlugIn",
                pluginType: null,
                parkingSpace: 3,
                parkingSpaceId: 12345
            }
        ],
        identifier: "c603389f02b64fb8a8a2fadef871c44f",
        chargerStatus: "Faulted",
        connectionState: "false"
    }

    const addChargerListExpectation = {
        chargerID: like("PactTestCharger3"),
        commonName: like("PactTestCharger3"),
        authorizationState: like(true),
        location: like({
            lat_Y: like(36.7389),
            lon_X: like(95.2735)
        }),
        chargerVersion: null,
        chargerType: like("SiemensCharger"),
        chargingMode: term({
            matcher: "STD|SEQ",
            generate: "STD",
        }),
        modelID: null,
        power: like(11.5),
        connected: like(false),
        efficiency: like(100),
        dataIngestRate: like(60),
        isAuthRequired: like(false),
        connectors: eachLike({
            connectorID: 1,
            power: 11.5,
            type: "ACPlugIn",
            pluginType: null,
            parkingSpace: 3,
            parkingSpaceId: 12345
        }),
        identifier: like("c603389f02b64fb8a8a2fadef871c44f"),
        chargerStatus: like("Faulted"),
        connectionState: like("false")
    }

    const updateChargerExample = {
        chargerID: "PactTestCharger2",
        commonName: "PactTestCharger2Updated",
        authorizationState: true,
        location: {
            lon_X: 95.2735,
            lat_Y: 36.7389
        },
        chargerVersion: null,
        chargerType: "SiemensCharger",
        chargingMode: "STD",
        modelID: null,
        power: 11.5,
        connected: false,
        efficiency: 100,
        dataIngestRate: 60,
        isAuthRequired: false,
        connectors: [
            {
                connectorID: 1,
                power: 11.5,
                type: "ACPlugIn",
                pluginType: null,
                parkingSpace: 3,
                parkingSpaceId: 12345
            }
        ],
        identifier: "c603389f02b64fb8a8a2fadef871c22f",
        chargerStatus: "Faulted",
        connectionState: "false"
    }

    const updateChargerListExpectation = {
        chargerID: like("PactTestCharger2"),
        commonName: like("PactTestCharger2Updated"),
        authorizationState: like(true),
        location: like({
            lat_Y: like(36.7389),
            lon_X: like(95.2735)
        }),
        chargerVersion: null,
        chargerType: like("SiemensCharger"),
        chargingMode: term({
            matcher: "STD|SEQ",
            generate: "STD",
        }),
        modelID: null,
        power: like(11.5),
        connected: like(false),
        efficiency: like(100),
        dataIngestRate: like(60),
        isAuthRequired: like(false),
        connectors: eachLike({
            connectorID: 1,
            power: 11.5,
            type: "ACPlugIn",
            pluginType: null,
            parkingSpace: 3,
            parkingSpaceId: 12345
        }),
        identifier: like("c603389f02b64fb8a8a2fadef871c22f"),
        chargerStatus: like("Faulted"),
        connectionState: like("false")
    }

    const removeChargerListExpectation = like("PactTestCharger2");

    before(() => provider.setup());
    afterEach(() => provider.verify());
    after(() => provider.finalize());

    describe("Assetmanagement API test cases", () => {
        it("Chargers Exists", async () => {
            await provider.addInteraction({
                state: 'get all chargers',
                uponReceiving: 'get all chargers',
                withRequest: {
                    method: 'GET',
                    path: '/chargers',
                    headers: {
                        "Accept": "application/json, text/plain, */*"
                    }
                },
                willRespondWith: {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8'
                    },
                    body: getChargerListExpectation
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            const actualResult = await api.getAllChargers();

            expect(actualResult).with.length.greaterThanOrEqual(1);
        });

        it("get Charger By Id", async () => {
            await provider.addInteraction({
                state: 'get charger by ID',
                uponReceiving: 'get charger with ID PactTestCharger2',
                withRequest: {
                    method: 'GET',
                    path: '/charger/PactTestCharger2',
                    headers: {
                        "Accept": "application/json, text/plain, */*"
                    }
                },
                willRespondWith: {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8'
                    },
                    body: like(getChargerByIDBody),
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            // make request to Pact mock server
            const actualResult = await api.getCharger("PactTestCharger2");

            expect(actualResult).to.deep.eq(getChargerByIDExample);
        });

        it("get Non Existing Charger", async () => {
            await provider.addInteraction({
                state: 'get not existing charger',
                uponReceiving: 'get charger with ID UnknownCharger',
                withRequest: {
                    method: 'GET',
                    path: '/charger/UnknownCharger',
                    headers: {
                        "Accept": "application/json, text/plain, */*"
                    }
                },
                willRespondWith: {
                    status: 404
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            // make request to Pact mock server
            await expect(api.getCharger("UnknownCharger")).rejectedWith("Request failed with status code 404");
        });

        it("add Charger", async () => {
            await provider.addInteraction({
                state: 'creating new charger',
                uponReceiving: 'add new charger',
                withRequest: {
                    method: 'POST',
                    path: '/charger',
                    body: addChargerExample,
                },
                willRespondWith: {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8'
                    },
                    body: addChargerListExpectation
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            const actualResult = await api.addCharger(addChargerExample);

            expect(actualResult).to.deep.eq(addChargerExample);
        });

        it("update Charger", async () => {
            await provider.addInteraction({
                state: 'update charger',
                uponReceiving: 'update charger',
                withRequest: {
                    method: 'PUT',
                    path: '/charger/PactTestCharger2',
                    body: updateChargerExample,
                    headers: {
                        "Accept": "application/json, text/plain, */*"
                    }
                },
                willRespondWith: {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8'
                    },
                    body: updateChargerListExpectation
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            const actualResult = await api.updateCharger("PactTestCharger2" ,updateChargerExample);

            expect(actualResult).to.deep.eq(updateChargerExample);
        });

        it("remove Charger", async () => {
            await provider.addInteraction({
                state: 'delete charger by ID',
                uponReceiving: 'remove charger',
                withRequest: {
                    method: 'DELETE',
                    path: '/charger/PactTestCharger2',
                    headers: {
                        "Accept": "application/json, text/plain, */*"
                    }
                },
                willRespondWith: {
                    status: 200,
                    headers: {
                        'Content-Type': "text/html; charset=utf-8"
                    },
                    body: removeChargerListExpectation
                },
            });

            const api = new AssetManagementService(provider.mockService.baseUrl);

            const actualResult = await api.deleteCharger("PactTestCharger2");

            expect(actualResult).to.deep.eq("PactTestCharger2");
        });
    })
})
