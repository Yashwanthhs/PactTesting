export class ChargerRepositry {
    chargers: Array<any>;
    constructor() {
        this.chargers = [
            {
                chargerID: "PactTestCharger1",
                commonName: "PactTestCharger1",
                authorizationState: true,
                location: {
                    lon_X: 95.2735,
                    lat_Y: 36.7389,
                },
                chargerVersion: null,
                chargerType: "SiemensCharger",
                chargingMode: "STD",
                modelID: null,
                power: 11.5,
                connected: false,
                efficiency: 100,
                dataIngestRate: 60,
                isAuthRequired: false,
                connectors: [
                    {
                        connectorID: 1,
                        power: 11.5,
                        type: "ACPlugIn",
                        pluginType: null,
                        parkingSpace: 3,
                        parkingSpaceId: 12345
                    }
                ],
                identifier: "c603389f02b64fb8a8a2fadef871c22f",
                chargerStatus: "Faulted",
                connectionState: "false"
            },
            {
                chargerID: "PactTestCharger2",
                commonName: "PactTestCharger2",
                authorizationState: true,
                location: {
                    lon_X: 95.2735,
                    lat_Y: 36.7389,
                },
                chargerVersion: null,
                chargerType: "SiemensCharger",
                chargingMode: "STD",
                modelID: null,
                power: 11.5,
                connected: false,
                efficiency: 100,
                dataIngestRate: 60,
                isAuthRequired: false,
                connectors: [
                    {
                        connectorID: 1,
                        power: 11.5,
                        type: "ACPlugIn",
                        pluginType: null,
                        parkingSpace: 3,
                        parkingSpaceId: 12345
                    }
                ],
                identifier: "c603389f02b64fb8a8a2fadef871c22f",
                chargerStatus: "Faulted",
                connectionState: "false"
            }
        ]
    }

    getChargers() {
        return this.chargers;
    }

    getChargerById(chargerId: string) {
        return this.chargers.find((charger) => charger.chargerID === chargerId);
    }

    addChargerById(chargerInfo: any) {
        if(chargerInfo){
            this.chargers.push(chargerInfo);
        }
        const addedChargerInfo = this.chargers.find((charger) => charger.chargerID === chargerInfo?.chargerID);
        return addedChargerInfo;
    }

    updateChargerById(chargerId: string, chargerInfo: any) {
        const index = this.chargers.findIndex((charger) => charger.chargerID === chargerId)
        if(chargerInfo && index){
            this.chargers[index] = chargerInfo
        }
        return this.chargers.find((charger) => charger.chargerID === chargerId);
    }

    deleteChargerById(chargerId: string) {
        const index = this.chargers.findIndex((charger) => charger.chargerID === chargerId)
        this.chargers.splice(index, 1);
        const chargerInfo =  this.chargers.find((charger) => charger.chargerID === chargerId);
        if(chargerInfo === undefined){
            return chargerId;
        }
        return chargerInfo;
    }
}

const chargerRepositry = new ChargerRepositry();
export default chargerRepositry;