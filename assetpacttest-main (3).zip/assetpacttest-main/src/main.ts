import express from "express";
import { chargerRoutes } from "./Routes/chargerRoute";

const app = express();
const port = 8080;

const init = () => {
    app.use(chargerRoutes);
    return app.listen(port, () => console.log(`AssetMangement API listening on port ${port}...`));
};

init();