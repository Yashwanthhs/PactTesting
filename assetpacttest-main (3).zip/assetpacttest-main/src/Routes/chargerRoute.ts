import express from "express";
import { chargerController } from "../controllers/chargerController";
const chargerRoutes = express.Router();

chargerRoutes.get("/chargers", chargerController.getChargers);
chargerRoutes.get("/charger/:id", chargerController.getChargerById);
chargerRoutes.post("/charger", chargerController.addCharger);
chargerRoutes.put("/charger/:id", chargerController.updateChargerById);
chargerRoutes.delete("/charger/:id", chargerController.deleteChargerById);
export { chargerRoutes };
