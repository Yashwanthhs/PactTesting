import { Request, Response } from "express";
import chargerRepositry from "../Database/ChargersRepo";

export class ChargerController {
    async getChargers(req: Request, res: Response) {
        console.log("Get Chargers");
        res.send(chargerRepositry.getChargers());
    }

    async getChargerById(req: Request, res: Response) {
        console.log("fetching charger info for id: ", req.params.id);
        const charger = chargerRepositry.getChargerById(req.params.id);
        charger ? res.send(charger) : res.status(404).send({message: "charger not found"})
    }

    async addCharger(req: Request, res: Response) {
        console.log("adding charger", req?.body);
        const chargerInfo = chargerRepositry.addChargerById(req?.body);
        chargerInfo ? res.send(chargerInfo) : res.status(404).send({message: "charger not found"})
    }

    async updateChargerById(req: Request, res: Response) {
        console.log("updating charger with id: ", req.params.id, req?.body);
        const charger = chargerRepositry.updateChargerById(req.params.id, req?.body);
        charger ? res.send(charger) : res.status(404).send({message: "charger not found"})
    }

    async deleteChargerById(req: Request, res: Response) {
        console.log("deleting charger with id: ", req.params.id);
        const charger = chargerRepositry.deleteChargerById(req.params.id);
        charger ? res.send(charger) : res.status(404).send({message: "charger not found"})
    }
}

const chargerController = new ChargerController();
export { chargerController };