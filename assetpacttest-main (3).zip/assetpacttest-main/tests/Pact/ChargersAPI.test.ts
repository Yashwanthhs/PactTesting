import express from "express";
import path from "path";
const { Verifier } = require('@pact-foundation/pact');
import { chargerRoutes } from "../../src/Routes/chargerRoute";

const app = express();
app.use(chargerRoutes);
const server = app.listen(8082, () => console.log(`Listening at port ${8082}`));

describe("Pact Verification", () => {

    it("validates the expectations of AssetManagementService", async () => {
        const opts = {
            logLevel: "INFO",
            providerBaseUrl: "http://localhost:8082",
            provider: "AssetManagementService",
            providerVersion: "1.0.0",
            pactUrls: [
                path.resolve(__dirname, '../../pacts/backendapp-assetmanagementservice.json')
            ],
            stateHandlers: {
                "get all chargers": () => {
                },
                "get charger by ID": () => {
                },
                "get not existing charger": () => {
                },
                "creating new charger": () => {
                },
                "update charger": () => {
                },
                "delete charger by ID": () => {
                }
            },
        };

        try {
            await new Verifier(opts).verifyProvider()
        } catch (error) {
            console.error('Error: ' + error.message)
            process.exit(1)
        } finally {
            server.close()
        }
    })
});